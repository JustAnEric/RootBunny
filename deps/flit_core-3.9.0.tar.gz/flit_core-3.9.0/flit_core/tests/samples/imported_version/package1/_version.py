"""Imposter docstring that shouldn't be used"""

__version__ = '0.5.8'
