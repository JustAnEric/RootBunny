BSD-3-Clause License
====================

.. include:: ../LICENSE.rst
